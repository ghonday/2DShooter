package TopDown;

public enum State {
    Menu(),
    Game()
}
