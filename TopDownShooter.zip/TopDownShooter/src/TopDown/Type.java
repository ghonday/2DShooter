package TopDown;

public enum Type {
    player(),
    bullet(),
    shop(),
    wall(),
    crate(),
    smallEnemy(),
    mediumEnemy(),
    largeEnemy(),
    bossEnemy()
}
