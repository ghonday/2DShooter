package TopDown;

public class RayGun {

    public RayGun(){
        System.out.println("Rez me i have ray gun");
    }
}
